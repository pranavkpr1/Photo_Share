# Jagnik

A Simple, beautiful and elegant photo Text merging app for your daily Image sharing activities on social media

## Screens
|![](https://github.com/bipin000/jagnik/blob/master/screens/Screenshot_20191228_171821.png) |
![](https://github.com/bipin000/jagnik/blob/master/screens/Screenshot_20191228_171839.png) |
![](https://github.com/bipin000/jagnik/blob/master/screens/Screenshot_20191228_171848.png) |
![](https://github.com/bipin000/jagnik/blob/master/screens/Screenshot_20191228_171856.png) |
![](https://github.com/bipin000/jagnik/blob/master/screens/Screenshot_20191228_171916.png) |
![](https://github.com/bipin000/jagnik/blob/master/screens/Screenshot_20191228_172210.png) |
![](https://github.com/bipin000/jagnik/blob/master/screens/Screenshot_20191228_172235.png) |
![](https://github.com/bipin000/jagnik/blob/master/screens/Screenshot_20191228_172251.png) |

## Live App
[Google Play Store link](https://play.google.com/store/apps/details?id=com.qubits.jagnik.jagnik)

## License
[MIT](https://choosealicense.com/licenses/mit/)